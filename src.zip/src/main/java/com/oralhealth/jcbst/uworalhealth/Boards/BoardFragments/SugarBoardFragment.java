package com.oralhealth.jcbst.uworalhealth.Boards.BoardFragments;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.oralhealth.jcbst.uworalhealth.R;
import com.oralhealth.jcbst.uworalhealth.SugarInteractive.SugarTrackerActivity;

public class SugarBoardFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             final Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_sugar_board, container, false);
        Button goPlayButton = (Button) view.findViewById(R.id.interactive_sugar_board);

        goPlayButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userName = getActivity().getIntent().getStringExtra("userName");
                Intent goPlayIntent = new Intent(getActivity(), SugarTrackerActivity.class);
                goPlayIntent.putExtra("userName",userName);
                startActivity(goPlayIntent);

            }
        });
        return view;
    }
}
