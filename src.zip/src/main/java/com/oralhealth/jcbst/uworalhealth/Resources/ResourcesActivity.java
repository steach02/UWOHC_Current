package com.oralhealth.jcbst.uworalhealth.Resources;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import com.oralhealth.jcbst.uworalhealth.Boards.BoardsActivity;
import com.oralhealth.jcbst.uworalhealth.R;
import com.oralhealth.jcbst.uworalhealth.Recruit.RecruitActivity;

public class ResourcesActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resources);
        setTitle(R.string.resources);
        getResourcesLinks();
    }

    public void getResourcesLinks() {
        TextView dentalClinic =(TextView)findViewById(R.id.dental_clinic);
        dentalClinic.setClickable(true);
        dentalClinic.setMovementMethod(LinkMovementMethod.getInstance());
        String dentalText = "&#8226; <a href='http://www.kingcounty.gov/depts/health/locations/dental.aspx'>Dental clinics in King County</a>";
        dentalClinic.setText(Html.fromHtml(dentalText));

        TextView medicalCare =(TextView)findViewById(R.id.medical_care);
        medicalCare.setClickable(true);
        medicalCare.setMovementMethod(LinkMovementMethod.getInstance());
        String medicalText = "&#8226; <a href='http://www.kingcounty.gov/depts/health/locations/homeless-health/mobile-medical-care.aspx'>Mobile medical care for people living homeless</a>";
        medicalCare.setText(Html.fromHtml(medicalText));

        TextView babyCare =(TextView)findViewById(R.id.baby_care);
        babyCare.setClickable(true);
        babyCare.setMovementMethod(LinkMovementMethod.getInstance());
        String babyCareText = "&#8226; <a href='http://www.kingcounty.gov/depts/health/child-teen-health/ABCD.aspx'>Access to Baby and Child Dentistry (ABCD)</a>";
        babyCare.setText(Html.fromHtml(babyCareText));

        TextView healthCenter =(TextView)findViewById(R.id.health_center);
        healthCenter.setClickable(true);
        healthCenter.setMovementMethod(LinkMovementMethod.getInstance());
        String healthCenterText = "&#8226; <a href='http://www.kingcounty.gov/depts/health/locations/community-health-centers.aspx'>Community Health Centers</a>";
        healthCenter.setText(Html.fromHtml(healthCenterText));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home_menu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.

        int id = item.getItemId();
        switch (id) {
            case R.id.home:
                Intent boardsIntent = new Intent(this, BoardsActivity.class);
                startActivity(boardsIntent);
                break;
            case R.id.volunteer:
                Intent volunteerIntent = new Intent(this, RecruitActivity.class);
                startActivity(volunteerIntent);
                break;
            default:
                return false;
        }
        return super.onOptionsItemSelected(item);
    }
}
