package com.oralhealth.jcbst.uworalhealth.Recruit;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.oralhealth.jcbst.uworalhealth.Boards.BoardsActivity;
import com.oralhealth.jcbst.uworalhealth.R;
import com.oralhealth.jcbst.uworalhealth.Resources.ResourcesActivity;

public class RecruitActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recruit);
        setTitle(R.string.volunteer);
        volunteer();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.

        int id = item.getItemId();
        switch (id) {
            case R.id.home:
                Intent boardsIntent = new Intent(this, BoardsActivity.class);
                startActivity(boardsIntent);
                break;
            case R.id.resources:
                Intent resourcesIntent = new Intent(this, ResourcesActivity.class);
                startActivity(resourcesIntent);
                break;
            default:
                return false;
        }
        return super.onOptionsItemSelected(item);
    }

    public void volunteer() {
        Button volunteerButton = (Button) findViewById(R.id.recruit_button);
        volunteerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                LayoutInflater layoutInflater = LayoutInflater.from(RecruitActivity.this);
                View promptView = layoutInflater.inflate(R.layout.recruit_form, null);
                final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(RecruitActivity.this);
                alertDialogBuilder.setView(promptView);

                final EditText firstNameEditText = (EditText) promptView.findViewById(R.id.first_name_edit_text);
                final EditText lastNameEditText = (EditText) promptView.findViewById(R.id.last_name_edit_text);
                final EditText emailEditText = (EditText) promptView.findViewById(R.id.email_edit_text);

                // setup a dialog window
                alertDialogBuilder.setCancelable(false)
                        .setPositiveButton("Submit", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                String firstNameInput = firstNameEditText.getText().toString().trim();
                                String lastNameInput = lastNameEditText.getText().toString().trim();
                                String emailInput = emailEditText.getText().toString().trim();
                                String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
                                String letterPattern = "[a-zA-Z]+";

                                if (firstNameInput.equals("") && lastNameInput.equals("") && emailInput.equals("") &&
                                        !emailInput.matches(emailPattern) && !firstNameInput.matches(letterPattern) && !lastNameInput.matches(letterPattern)) {
                                    Toast.makeText(getApplicationContext(), "Please enter all the required fields and only use letters for your names", Toast.LENGTH_LONG).show();
                                } else {
                                    Intent emailIntent = new Intent(Intent.ACTION_SEND);
                                    emailIntent.putExtra(emailIntent.EXTRA_EMAIL, new String[]
//ENTER EMAIL HERE
{"*********"});
                                    emailIntent.putExtra(emailIntent.EXTRA_SUBJECT, "New Volunteer Request");
                                    emailIntent.putExtra(emailIntent.EXTRA_TEXT, "First Name: " + firstNameInput + "\n"
                                            + "Last Name: " + lastNameInput + "\n"
                                            + " Contact Email: " + emailInput);
                                    emailIntent.setType("message/rfc822");
                                    startActivity(emailIntent);
                                }
                            }
                        })
                        .setNegativeButton("Cancel",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        dialog.cancel();
                                    }
                                });

                // create an alert dialog
                AlertDialog alert = alertDialogBuilder.create();
                alert.show();
            }
        });
    }
}
