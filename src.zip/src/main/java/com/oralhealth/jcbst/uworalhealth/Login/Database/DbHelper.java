package com.oralhealth.jcbst.uworalhealth.Login.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.oralhealth.jcbst.uworalhealth.Login.Database.Contact;

public class DbHelper extends SQLiteOpenHelper {
    //Db info
    private static final int db_version = 4;
    private static final String DATABASE_NAME = "user_database";
    private static final String TABLE_NAME = "USERS";
    //User info
    private static final String columns_Email = "email";
    private static final String columns_UserName = "userName";
    private static final String columns_Password = "password";
    // Values used for the clock
    private static final String columns_timeRemaining = "timeRemaining";
    private static final String columns_timeStamp = "timeStamp";
    //total amout of sugar for the corresponding amount of time
    private static final String columns_SugarInGrams = "sugarInGrams";

    SQLiteDatabase db;
    //create the db table
    private static final String TABLE_CREATE = "create table USERS (userName text primary key not null " +
            ", email text not null , password text not null, sugarInGrams integer not null, timeRemaining long not null, timeStamp long not null);";

   //constructor
    public DbHelper(Context context) {
        super(context, DATABASE_NAME, null, db_version);
    }
    //only runs if table is not created
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TABLE_CREATE);
        this.db = db;
    }
    //add new row(create new user)
    public void insertContact(Contact c) {
        db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(columns_Email, c.getEmail());
        values.put(columns_UserName, c.getUserName());
        values.put(columns_Password, c.getPassword());
        values.put(columns_SugarInGrams, 0);
        values.put(columns_timeRemaining,c.getTimeRemaining());
        values.put(columns_timeStamp,c.getTimeStamp());
        db.insert(TABLE_NAME,null, values);
        db.close();
    }

    //see if the user exists return his password
    public String searchPass(String userName) {
        db = this.getReadableDatabase();
        String query = "SELECT userName, password FROM " + TABLE_NAME;
        Cursor cursor = db.rawQuery(query, null);
        String a, b;
        b = "not found";
        if (cursor.moveToFirst()) {
            do {
                a = cursor.getString(0);
                if (a.equalsIgnoreCase(userName)) {
                    b = cursor.getString(1);
                    break;
                }
            } while (cursor.moveToNext());
        }
        db.close();
        return b;
    }
    //se if userName exists return true/false
    public boolean userNameSearch(String userName){
        // this method is for sign up to test if a username exists
        boolean b = false;

        db = this.getReadableDatabase();
        String query = "SELECT userName FROM " + TABLE_NAME;
        Cursor cursor = db.rawQuery(query, null);
        String a;

        if (cursor.moveToFirst()) {
            do {
                a = cursor.getString(0);
                if (a.equalsIgnoreCase(userName)) {
                    b = true;
                    break;
                }
            } while (cursor.moveToNext());
        }
        return b;
    }
    //update sugar in grams;
    public void updateSugarTotal(String userName, int D){
        db = this.getWritableDatabase();
        db.execSQL("UPDATE USERS SET sugarInGrams=" + D + " WHERE userName = '" + userName + "'");
        db.close();
    }

    //gets the sugar in grams;
    public int getSugarTotal(String userName){

        int grams = 0;
        db = this.getReadableDatabase();
        String query = "SELECT sugarInGrams FROM " + TABLE_NAME +" WHERE userName = '"+userName+"'";
        Cursor cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst()) {
            grams = cursor.getInt(0);
        }

        return grams;
    }
    //update time remaining and time stamp;
    public void updateTimeRemainingAndTimeStamp(String userName, long timeRemaining, long timeStamp){
        db = this.getWritableDatabase();

        ContentValues cv = new ContentValues();
        cv.put(columns_timeRemaining, timeRemaining);
        cv.put(columns_timeStamp, timeStamp);
        db.update(TABLE_NAME, cv, "userName = '" + userName + "'", null);

        db.close();
    }

    //gets the time remaining for counter;
    public long getTimeRemaining(String userName){

        long timeRemaining = 0;
        db = this.getReadableDatabase();
        String query = "SELECT timeRemaining FROM " + TABLE_NAME +" WHERE userName = '"+userName+"'";
        Cursor cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst()) {
            timeRemaining = cursor.getLong(0);
        }
        db.close();
        return timeRemaining;
    }

    public long getTimeStamp(String userName){

        long timeStamp = 0;
        db = this.getReadableDatabase();
        String query = "SELECT timeStamp FROM " + TABLE_NAME +" WHERE userName = '"+userName+"'";
        Cursor cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst()) {
            timeStamp = cursor.getLong(0);
        }
        db.close();
        return timeStamp;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String query = "DROP TABLE IF EXISTS " + TABLE_NAME;
        db.execSQL(query);
        this.onCreate(db);
    }
}
