package com.oralhealth.jcbst.uworalhealth.Boards;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;

import com.oralhealth.jcbst.uworalhealth.R;
import com.oralhealth.jcbst.uworalhealth.Resources.ResourcesActivity;
import com.oralhealth.jcbst.uworalhealth.Recruit.RecruitActivity;

public class BoardsActivity extends AppCompatActivity implements ActionBar.TabListener {

    private ViewPager boardsPager;
    private ActionBar actionBar;
    private String[] tabs = {"SUGAR", "Coming Soon..."};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_boards);
        setTitle(R.string.sugar_board);

        boardsPager = (ViewPager) findViewById(R.id.board_pager);
        actionBar = getSupportActionBar();
        actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);
        for (String tab_name : tabs) {
            actionBar.addTab(actionBar.newTab().setText(tab_name)
                    .setTabListener(this));
        }
        PagerAdapter boardPagerAdapter = new PagerAdapter(getSupportFragmentManager());

        boardsPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                actionBar.setSelectedNavigationItem(position);
                // When new board is created set the title of the
                // board here.
                switch (position) {
                    case 0:
                        setTitle(R.string.sugar_board);
                        break;
                    case 1:
                        setTitle(R.string.coming_soon);
                        break;
                    default:
                        break;
                }

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
        boardsPager.setAdapter(boardPagerAdapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home_menu, menu);

        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.

        int id = item.getItemId();
        switch (id) {
            case R.id.volunteer:
                Intent volunteerIntent = new Intent(this, RecruitActivity.class);
                startActivity(volunteerIntent);
                break;
            case R.id.resources:
                Intent resourcesIntent = new Intent(this, ResourcesActivity.class);
                startActivity(resourcesIntent);
                break;
            default:
                return false;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onTabSelected(ActionBar.Tab tab, FragmentTransaction ft) {
        boardsPager.setCurrentItem(tab.getPosition());
    }

    @Override
    public void onTabUnselected(ActionBar.Tab tab, FragmentTransaction ft) {
        
    }

    @Override
    public void onTabReselected(ActionBar.Tab tab, FragmentTransaction ft) {
        
    }
}
