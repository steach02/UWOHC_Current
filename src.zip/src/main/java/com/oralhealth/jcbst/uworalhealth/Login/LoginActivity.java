package com.oralhealth.jcbst.uworalhealth.Login;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.oralhealth.jcbst.uworalhealth.Boards.BoardsActivity;
import com.oralhealth.jcbst.uworalhealth.Login.Database.Contact;
import com.oralhealth.jcbst.uworalhealth.Login.Database.DbHelper;
import com.oralhealth.jcbst.uworalhealth.R;

public class LoginActivity extends Activity {
    DbHelper dbHelper = new DbHelper(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    }

    public void signUp(final View view) {
        LayoutInflater layoutInflater = LayoutInflater.from(LoginActivity.this);
        final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(LoginActivity.this);
        final View promptView = layoutInflater.inflate(R.layout.sign_up_form, null);

        alertDialogBuilder.setView(promptView);
        // setup a dialog window
        alertDialogBuilder.setCancelable(false)
                .setPositiveButton("Submit", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        final EditText userName = (EditText) promptView.findViewById(R.id.userName);
                        final EditText email = (EditText) promptView.findViewById(R.id.sign_Up_Email);
                        final EditText password = (EditText) promptView.findViewById(R.id.password);
                        final EditText confirmPassword = (EditText) promptView.findViewById(R.id.password_confirm);

                        final String sUserName = userName.getText().toString().trim();
                        final String sEmail = email.getText().toString().trim();
                        final String sPassword = password.getText().toString().trim();
                        final String sConfirmPassword = confirmPassword.getText().toString().trim();
                        //test user name aswell
                        String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
                        if (!sEmail.equals("") && !sPassword.equals("") && !sUserName.equals("") && sEmail.matches(emailPattern)) {
                            if (!dbHelper.userNameSearch(sUserName)) {
                                if (sPassword.equalsIgnoreCase(sConfirmPassword)) {

                                    Contact c = new Contact();
                                    c.setUserName(sUserName);
                                    c.setEmail(sEmail);
                                    c.setPassword(sPassword);
                                    c.setTimeRemaining(60000);
                                    c.setTimeStamp(-1);
                                    dbHelper.insertContact(c);
                                    Toast.makeText(getApplicationContext(), "You now have an account with us!", Toast.LENGTH_SHORT).show();
                                } else {
                                    Toast.makeText(getApplicationContext(), "request failed passwords do not match", Toast.LENGTH_SHORT).show();
                                    signUp(view);
                                }
                            } else {
                                Toast.makeText(getApplicationContext(), "The user name has already been used", Toast.LENGTH_SHORT).show();
                                signUp(view);
                            }
                        } else {
                            Toast.makeText(getApplicationContext(), "Request failed, make sure all fields are completed and email is valid", Toast.LENGTH_LONG).show();
                            signUp(view);
                        }
                    }
                })
                .setNegativeButton("Cancel",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });

        // create an alert dialog
        AlertDialog alert = alertDialogBuilder.create();
        alert.show();
    }

    public void signIn(final View view) {

        LayoutInflater layoutInflater = LayoutInflater.from(LoginActivity.this);
        final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(LoginActivity.this);
        final View promptView = layoutInflater.inflate(R.layout.sign_in, null);

        alertDialogBuilder.setView(promptView);
        // setup a dialog window
        alertDialogBuilder.setCancelable(false)
                .setPositiveButton("Submit", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                        final EditText password = (EditText) promptView.findViewById(R.id.login_password);
                        final EditText userName = (EditText) promptView.findViewById(R.id.loginUserName);

                        final String sPassword = password.getText().toString();
                        final String sUserName = userName.getText().toString();
                        final String dbPass = dbHelper.searchPass(sUserName);
                        //check db for user name pass word
                        if (sPassword.equalsIgnoreCase(dbPass)) {

                            Intent homeIntent = new Intent(LoginActivity.this, BoardsActivity.class);
                            SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(LoginActivity.this);
                            SharedPreferences.Editor editor = preferences.edit();
                            editor.putString("userName", sUserName);
                            editor.apply();

                            startActivity(homeIntent);
                        } else {
                            Toast.makeText(getApplicationContext(), "User name and password do not match", Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .setNegativeButton("Cancel",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });

        // create an alert dialog
        AlertDialog alert = alertDialogBuilder.create();
        alert.show();
    }
}
