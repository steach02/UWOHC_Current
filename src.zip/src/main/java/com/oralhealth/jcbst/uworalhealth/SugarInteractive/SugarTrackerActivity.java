package com.oralhealth.jcbst.uworalhealth.SugarInteractive;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.oralhealth.jcbst.uworalhealth.Boards.BoardsActivity;
import com.oralhealth.jcbst.uworalhealth.Login.Database.DbHelper;
import com.oralhealth.jcbst.uworalhealth.R;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class SugarTrackerActivity extends AppCompatActivity {

    private String userName;
    private TextView countDownTextView;
    private TextView lbsConversion, ozConversion, tspConversion;
    private Button startButton, resetButton, submitButton;
    EditText sugarTotalText;
    private DbHelper helper;
    private long time, timeStamp;
    private CountDownTimer cdt;
    //use this variable to change the duration of the clock
    private long startNum = 86400000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sugar_tracker);
        setTitle(R.string.sugar_tracker);

        sugarTotalText = (EditText) findViewById(R.id.sugar_consumed_edit_text);
        sugarTotalText.setEnabled(false);

        // Get username from shared preferences
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(SugarTrackerActivity.this);
        this.userName = preferences.getString("userName", "");
        if (userName.equals("")) {
            Toast.makeText(this, "Something went wrong", Toast.LENGTH_SHORT).show();
        }
        helper = new DbHelper(this);
        timeStamp = helper.getTimeStamp(userName);
        System.out.println(timeStamp);
        if (timeStamp == -1) {
            time = setTimeRemaining();
            System.out.println("in if");

            // This will execute if the timer is NOT running.
            instantiateViews();
            startButton.setEnabled(true);
            startButton.setBackgroundResource(R.drawable.button_shape);
            submitButton.setEnabled(false);
            submitButton.setBackgroundResource(R.drawable.disabled_button_shape);
            resetButton.setEnabled(false);
            resetButton.setBackgroundResource(R.drawable.disabled_button_shape);
            if (helper.getSugarTotal(userName) != 0) {
                convert();
            }
        } else {

            time = setTimeRemaining();
            System.out.println(time + "time");

            // This will execute if the timer IS running.
            instantiateViews();
            startTimer();
            convert();
            startButton.setEnabled(false);
            startButton.setBackgroundResource(R.drawable.disabled_button_shape);
            submitButton.setEnabled(true);
            submitButton.setBackgroundResource(R.drawable.button_shape);
            resetButton.setEnabled(true);
            resetButton.setBackgroundResource(R.drawable.button_shape);
            sugarTotalText.setEnabled(true);

        }
    }

    public void instantiateViews() {
        countDownTextView = (TextView) findViewById(R.id.countdown_timer);
        startButton = (Button) findViewById(R.id.start_timer);
        resetButton = (Button) findViewById(R.id.reset_timer);
        submitButton = (Button) findViewById(R.id.submit_button_consumed);
        lbsConversion = (TextView) findViewById(R.id.lbs_conversion);
        ozConversion = (TextView) findViewById(R.id.oz_conversions);
        tspConversion = (TextView) findViewById(R.id.tsp_conversion);
        setStartOnClick();
        setResetOnClick();
        setSubmitOnClick();
        String str = String.format("%02d:%02d:%02d", TimeUnit.MILLISECONDS.toHours(time),
                TimeUnit.MILLISECONDS.toMinutes(time) - TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(time)),
                TimeUnit.MILLISECONDS.toSeconds(time) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(time)));
        countDownTextView.setText(str);
    }

    public void setStartOnClick() {
        startButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                helper.updateSugarTotal(userName, 0);
                lbsConversion.setText("");
                ozConversion.setText("");
                tspConversion.setText("");
                startTimer();
                sugarTotalText.setEnabled(true);
                submitButton.setEnabled(true);
                submitButton.setBackgroundResource(R.drawable.button_shape);
                resetButton.setEnabled(true);
                resetButton.setBackgroundResource(R.drawable.button_shape);
                startButton.setEnabled(false);
                startButton.setBackgroundResource(R.drawable.disabled_button_shape);
            }
        });
    }

    public void setResetOnClick() {
        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cdt.cancel();
                helper.updateTimeRemainingAndTimeStamp(userName, startNum, -1);
                helper.updateSugarTotal(userName, 0);
                time = startNum;
                String str = String.format("%02d:%02d:%02d", TimeUnit.MILLISECONDS.toHours(time),
                        TimeUnit.MILLISECONDS.toMinutes(time) - TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(time)),
                        TimeUnit.MILLISECONDS.toSeconds(time) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(time)));
                countDownTextView.setText(str);
                sugarTotalText.setEnabled(false);
                startButton.setEnabled(true);
                startButton.setBackgroundResource(R.drawable.button_shape);
                submitButton.setEnabled(false);
                submitButton.setBackgroundResource(R.drawable.disabled_button_shape);
                resetButton.setEnabled(false);
                resetButton.setBackgroundResource(R.drawable.disabled_button_shape);
                lbsConversion.setText("");
                ozConversion.setText("");
                tspConversion.setText("");
            }
        });
    }

    public void setSubmitOnClick() {
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!sugarTotalText.getText().toString().equals("")) {
                    try {
                        int sugarTotal = Integer.parseInt(sugarTotalText.getText().toString().trim());
                        helper.updateSugarTotal(userName, sugarTotal + helper.getSugarTotal(userName));
                        convert();
                        sugarTotalText.setText("");
                    } catch (Exception e) {
                        Toast.makeText(getApplicationContext(), "Sorry, that amount doesn't seem realistic. Try again.", Toast.LENGTH_LONG).show();
                        sugarTotalText.setText("");
                    }
                }
            }
        });
    }

    public void startTimer() {

        cdt = new CountDownTimer(time, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                String str = String.format("%02d:%02d:%02d", TimeUnit.MILLISECONDS.toHours(millisUntilFinished),
                        TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished) - TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(millisUntilFinished)),
                        TimeUnit.MILLISECONDS.toSeconds(millisUntilFinished) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished)));
                countDownTextView.setText(str);
                System.out.println(str);

                time = millisUntilFinished;
            }

            @Override
            public void onFinish() {
                if (time < 2000) {
                    time = startNum;
                    String str = String.format("%02d:%02d:%02d", TimeUnit.MILLISECONDS.toHours(startNum),
                            TimeUnit.MILLISECONDS.toMinutes(startNum) - TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(0)),
                            TimeUnit.MILLISECONDS.toSeconds(startNum) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(startNum)));
                    countDownTextView.setText(str);
                    helper.updateTimeRemainingAndTimeStamp(userName, startNum, -1);

                    startButton.setEnabled(true);
                    startButton.setBackgroundResource(R.drawable.button_shape);
                    submitButton.setEnabled(false);
                    submitButton.setBackgroundResource(R.drawable.disabled_button_shape);
                    resetButton.setEnabled(false);
                    resetButton.setBackgroundResource(R.drawable.disabled_button_shape);
                    sugarTotalText.setEnabled(false);
                }
            }
        }.start();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.sugar_tracker_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.

        int id = item.getItemId();
        switch (id) {
            case R.id.home:
                Intent homeIntent = new Intent(this, BoardsActivity.class);
                startActivity(homeIntent);
                break;
            default:
                return false;
        }
        return super.onOptionsItemSelected(item);
    }

    public void convert() {
        long sugar = helper.getSugarTotal(userName);
        double pounds = sugar * 0.00220462262;
        double ounces;
        if (sugar == 0) {
            ounces = 0;
        } else {
            ounces = sugar / 28.4;
        }
        double tsp = sugar * 2.5;
        DecimalFormat df = new DecimalFormat("#.##");
        df.setRoundingMode(RoundingMode.CEILING);
        if (sugar == 0) {
            sugarTotalText.setText("");
            lbsConversion.setText("");
            ozConversion.setText("");
            tspConversion.setText("");
        } else {
            lbsConversion.setText(sugar + " gm = " + df.format(pounds) + " lb(s)");

            ozConversion.setText(sugar + " gm = " + df.format(ounces) + " oz");

            tspConversion.setText(sugar + " gm = " + df.format(tsp) + " tsp");
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        //stop cdt
        // update db if needed
        if (cdt != null) {
            cdt.cancel();
        }
        if (time != startNum && time != 0) {
            helper.updateTimeRemainingAndTimeStamp(userName, time, getDateTime());
        }
    }

    @Override
    protected void onPause() {
        //update the db if needed
        super.onPause();
        if (time != startNum && time != 0) {
            System.out.println();
            helper.updateTimeRemainingAndTimeStamp(userName, time, getDateTime());
        }
    }

    @Override
    protected void onResume() {
        //update the db if needed

        super.onResume();
        time = setTimeRemaining();
        if (helper.getTimeRemaining(userName) != startNum && helper.getTimeRemaining(userName) != 0) {
            startTimer();
        }
    }

    private long getDateTime() {

        Calendar c = Calendar.getInstance();
        SimpleDateFormat df = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss", Locale.US);
        String formattedDate = df.format(c.getTime());

        try {
            Date dateTime = df.parse(formattedDate);
            long inMilliSeconds = dateTime.getTime();
            return inMilliSeconds;
        } catch (ParseException pe) {
            pe.getMessage();
        }
        return -1;
    }

    private long setTimeRemaining() {
        long TR = startNum;
        long temp1 = helper.getTimeRemaining(userName);

        if (temp1 != TR && temp1 != 0) {
            if ((getDateTime() - helper.getTimeStamp(userName)) < helper.getTimeRemaining(userName)) {
                //if the current time minus the time since last opened is less than the time remaining update time remaining and continue counting
                TR = helper.getTimeRemaining(userName) - (getDateTime() - helper.getTimeStamp(userName));
                helper.updateTimeRemainingAndTimeStamp(userName, TR, 0);

                return TR;
            } else {
                // the countdown time is finished reset the values for for the time remaining and set the time stamp to -1
                if (cdt != null) {
                    cdt.onFinish();
                }
                helper.updateTimeRemainingAndTimeStamp(userName, startNum, -1);
                return TR;
            }
        }

        return TR;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        if (cdt != null) {
            cdt.cancel();
        }
        if (time != startNum && time != 0) {
            long currentDateTime = getDateTime();
            helper.updateTimeRemainingAndTimeStamp(userName, time, currentDateTime);
        }
    }
}
