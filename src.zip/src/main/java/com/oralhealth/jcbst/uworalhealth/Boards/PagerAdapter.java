package com.oralhealth.jcbst.uworalhealth.Boards;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import com.oralhealth.jcbst.uworalhealth.Boards.BoardFragments.ComingSoonFragment;
import com.oralhealth.jcbst.uworalhealth.Boards.BoardFragments.SugarBoardFragment;

public class PagerAdapter extends FragmentPagerAdapter {
    public PagerAdapter(FragmentManager fm) {
        super(fm);

    }

    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
               SugarBoardFragment fragment = new SugarBoardFragment();
                Bundle b = new Bundle();
                fragment.setArguments(b);
                return fragment;
            case 1:
                return new ComingSoonFragment();
            default:
                break;
        }
        return null;
    }

    @Override
    public int getCount() {
        return 2;
    }
}

